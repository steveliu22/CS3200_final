package com.example.project.model;

public enum Category {
  EDUCATIONAL, MUSIC, HEALTHFITNESS, COMEDY, COOKING, VLOG, GAMING, MISCELLANEOUS
}
